package com.example.myapplication

import java.util.*

data class User(
    var fullName : String ?= null,
    var course : String ?= null,
    var bio : String ?= null,
    var dob : String ?= null
)