package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.ToDoListItem;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class ToDoList extends Fragment {

    private FirebaseAuth auth;
    private FirebaseDatabase database;
    private LinearLayout displayItemsLinearLayout;
    DrawerLayout drawerLayout;
    NavigationView navigationView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tdl, container, false);

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance();

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance("https://scholarly-login-default-rtdb.europe-west1.firebasedatabase.app/");

        displayItemsLinearLayout = view.findViewById(R.id.displayItemsLinearLayout);

        navigationView = view.findViewById(R.id.SideNavView);

        drawerLayout = view.findViewById(R.id.drawerLayout);


        // Get user ID from intent or from wherever it's stored
        String userId = auth.getCurrentUser().getUid();

        //Navigation Drawer
        view.findViewById(R.id.menuIcon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.Profile) {
                    // Navigate to ProfilePage
                    ProfileFragment profileFragment = new ProfileFragment();
                    requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, profileFragment)
                            .addToBackStack(null).commit();
                }
                if (id == R.id.Home) {
                    // Navigate to Home
                    Intent intent = new Intent(getActivity(), HomePage.class);
                    startActivity(intent);
                }
                // Handle other menu item selections

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        Button addBtn = view.findViewById(R.id.addBtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AddListItemPage.class);
                startActivity(intent);
            }
        });


        // Query the Firebase Realtime Database to get items that match the user ID
        Query query = database.getReference("todo_list_items").orderByChild("dueDate");


        query.addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d("ToDoList", "onDataChange: start");
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    ToDoListItem item = snapshot.getValue(ToDoListItem.class);
                    if (item != null && item.getUserId().equals(userId)) {
                        Log.d("ToDoList", "onDataChange: creating item layout");

                        // Test to see if fragment is attached when method is called
                        Activity activity = getActivity();
                        if (activity == null) {
                            Log.d("ToDoList", "onDataChange: getActivity() returned null");
                            return;
                        }

                        // Create a new LinearLayout to hold the item details
                        LinearLayout itemLayout = new LinearLayout(getActivity());
                        itemLayout.setOrientation(LinearLayout.HORIZONTAL);
                        itemLayout.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.item_background));
                        LinearLayout.LayoutParams itemLayoutParams = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                240);
                        itemLayoutParams.setMargins(20, 20, 20, 0);
                        itemLayout.setLayoutParams(itemLayoutParams);
                        itemLayout.setPadding(20, 20, 20, 20);
                        itemLayout.setGravity(Gravity.CENTER_VERTICAL);
                        itemLayout.setClipToOutline(true);

                        // Create a TextView for the item name and add it to the item layout
                        TextView itemNameTextView = new TextView(getActivity());
                        itemNameTextView.setText(item.getItemName());
                        itemNameTextView.setTextColor(Color.WHITE);
                        itemNameTextView.setTextSize(20);
                        itemNameTextView.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT, // Set the layout height to WRAP_CONTENT
                                1.0f
                        ));
                        itemLayout.addView(itemNameTextView);

                        // Create a TextView for the due date and add it to the item layout
                        TextView dueDateTextView = new TextView(getActivity());
                        dueDateTextView.setText(item.getDueDate());
                        dueDateTextView.setTextColor(Color.WHITE);
                        dueDateTextView.setGravity(Gravity.END);
                        dueDateTextView.setTextSize(20);
                        dueDateTextView.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        ));
                        itemLayout.addView(dueDateTextView);

                        // Create a CheckBox to indicate if the item is done and add it to the item layout
                        CheckBox doneCheckBox = new CheckBox(getActivity());
                        doneCheckBox.setChecked(item.getDone());
                        doneCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                // Update the value of the "isDone" field in the Firebase Realtime Database for this item
                                snapshot.getRef().child("done").setValue(isChecked);
                            }
                        });

                        // Scale the size of the CheckBox
                        float scale = 1.5f; // 1.5 times larger
                        doneCheckBox.setScaleX(scale);
                        doneCheckBox.setScaleY(scale);

                        doneCheckBox.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        ));
                        itemLayout.addView(doneCheckBox);


                        // Create a button to delete the item and add it to the item layout
                        Button deleteButton = new Button(getActivity());
                        deleteButton.setText("Delete");
                        deleteButton.setBackgroundColor(Color.TRANSPARENT);
                        deleteButton.setTextColor(Color.WHITE);
                        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        ));
                        deleteButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                snapshot.getRef().removeValue();
                                displayItemsLinearLayout.removeView(itemLayout);
                                Toast.makeText(getActivity(), "Item Deleted!", Toast.LENGTH_SHORT).show();
                            }
                        });
                        itemLayout.addView(deleteButton);

                        // Add the item layout to the displayItemsLinearLayout
                        Log.d("ToDoList", "onDataChange: adding item layout to displayItemsLinearLayout");
                        displayItemsLinearLayout.addView(itemLayout);
                    }
                }
                Log.d("ToDoList", "onDataChange: end");
            }



            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
                // Implement your logic here
            }
        });

        return view;
    }
}
