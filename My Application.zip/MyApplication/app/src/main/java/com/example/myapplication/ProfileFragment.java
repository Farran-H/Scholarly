package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import android.view.View;

public class ProfileFragment extends Fragment {

    private TextView textviewFullName, textviewUserCourse, textviewUserBio, textviewUserDoB;
    private FirebaseAuth auth;
    private DatabaseReference databaseReference;
    DrawerLayout drawerLayout;
    NavigationView navigationView;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        drawerLayout = view.findViewById(R.id.drawerLayout);
        navigationView = view.findViewById(R.id.SideNavView);

        Button btnLogOut = view.findViewById(R.id.btnLogOut);
        Button btnEditProfile = view.findViewById(R.id.btnEditProfile);

        textviewFullName = view.findViewById(R.id.textviewFullName);
        textviewUserCourse = view.findViewById(R.id.textviewUserCourse);
        textviewUserBio = view.findViewById(R.id.textviewUserBio);
        textviewUserDoB = view.findViewById(R.id.textviewUserDoB);

        auth = FirebaseAuth.getInstance();
        String uid = auth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance("https://scholarly-login-default-rtdb.europe-west1.firebasedatabase.app/").getReference("Users");

        if (uid != null) {
            databaseReference.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        User user = snapshot.getValue(User.class);
                        if (user != null) {
                            textviewFullName.setText(user.getFullName());
                            textviewUserCourse.setText(user.getCourse());
                            textviewUserBio.setText(user.getBio());

                            String dob = user.getDob();
                            if (dob != null && !dob.isEmpty()) {
                                int age = calculateAge(dob);
                                String ageString = String.valueOf(age) + " Years Old";
                                textviewUserDoB.setText(ageString);

                            }
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Handle error if needed
                }
            });
        }

        view.findViewById(R.id.menuIcon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                // Navigate to Home Page
                if (id == R.id.Home) {
                    // Navigate Home
                    Intent intent = new Intent(getActivity(), HomePage.class);
                    startActivity(intent);
                }
                // Navigate to TDL Page
                if (id == R.id.List) {
                    Intent intent = new Intent(getActivity(), TDLPage.class);
                    startActivity(intent);
                }

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sign out and start SignupActivity (Java)
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getActivity(), SignUp.class);
                startActivity(intent);
                getActivity().finish();
            }
        });

        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start AddUserDetailsPageActivity (Kotlin)
                Intent intent = new Intent(getActivity(), AddUserDetailsPage.class);
                startActivity(intent);
            }
        });

        return view;
    }

    // Function to calculate age from Date of Birth string
    private int calculateAge(String dobString) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {
            Date dob = sdf.parse(dobString);
            Calendar dobCalendar = Calendar.getInstance();
            dobCalendar.setTime(dob);
            Calendar now = Calendar.getInstance();
            int age = now.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);
            if (now.get(Calendar.DAY_OF_YEAR) < dobCalendar.get(Calendar.DAY_OF_YEAR)) {
                age--;
            }
            return age;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
