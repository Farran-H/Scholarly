package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.StorageReference;

public class ScreenAfterLogin extends Fragment {

    // Global Vars
    FirebaseAuth auth;
    FirebaseUser user;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Button mapBtn2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        // Class Variables
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        drawerLayout = view.findViewById(R.id.drawerLayout);
        navigationView = view.findViewById(R.id.SideNavView);
        mapBtn2 = view.findViewById(R.id.mapBtn2);


        // Check if user is logged in
        if (user == null) {
            Intent intent = new Intent(getActivity(), SignUp.class);
            startActivity(intent);
            getActivity().finish();
        }

        // Icon for Navigation drawer
        view.findViewById(R.id.menuIcon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        // Listener for button navigation to map feature
        mapBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start the MapScreenActivity
                Intent intent = new Intent(getActivity(), MapsAct.class);
                startActivity(intent);
            }
        });

        // Functionality for when drawer is open
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                // Navigate to ProfilePage
                if (id == R.id.Profile) {
                    Log.d("Profile", "Profile click registered");
                    ProfileFragment profileFragment = new ProfileFragment();
                    Log.d("Profile", "Navigating to Profile");
                    requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, profileFragment)
                            .addToBackStack(null).commit();
                    Log.d("Profile", "success");
                }
                // Navigate to TDL page
                if (id == R.id.List) {
                    Intent intent = new Intent(getActivity(), TDLPage.class);
                    startActivity(intent);
                }
                // Close out drawer once navigation is complete

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
        return view;
    }
}