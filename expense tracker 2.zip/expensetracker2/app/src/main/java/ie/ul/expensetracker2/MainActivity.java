package ie.ul.expensetracker2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;





import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText expenseAmountEditText;
    private EditText expenseDescriptionEditText;
    private Button addExpenseButton;
    private ListView expensesListView;
    private ArrayList<String> expenses;
    private ArrayAdapter<String> expensesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

// Get a reference to the root of your Firebase Database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
// Get a reference to the "expenses" node in your Firebase Database
        DatabaseReference myRef = database.getReference().child("expenses");



        expenseAmountEditText = findViewById(R.id.expense_amount);
        expenseDescriptionEditText = findViewById(R.id.expense_description);
        addExpenseButton = findViewById(R.id.add_expense_button);
        expensesListView = findViewById(R.id.expenses_list);

        expenses = new ArrayList<>();
        expensesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expenses);
        expensesListView.setAdapter(expensesAdapter);

        addExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = expenseAmountEditText.getText().toString();
                String description = expenseDescriptionEditText.getText().toString();
                String expense = "€" + amount + " - " + description;
                expenses.add(expense);
                expensesAdapter.notifyDataSetChanged();
                expenseAmountEditText.setText("");
                expenseDescriptionEditText.setText("");
            }
        });

        expensesListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                expenses.remove(position);
                expensesAdapter.notifyDataSetChanged();
                return true;
            }
        });

        addExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = expenseAmountEditText.getText().toString();
                String description = expenseDescriptionEditText.getText().toString();
                String expense = "€" + amount + " - " + description;
                expenses.add(expense);
                expensesAdapter.notifyDataSetChanged();
                expenseAmountEditText.setText("");
                expenseDescriptionEditText.setText("");

                // Save expense to Firebase database
                myRef.push().setValue(expense);
            }
        });

    }
}
